package com.over3.listmaker

data class ListOfListsData(
    val listID : String,
    val listName : String,
    val listColor : Int
)
