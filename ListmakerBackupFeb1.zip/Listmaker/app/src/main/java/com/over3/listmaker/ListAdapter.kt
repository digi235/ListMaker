package com.over3.listmaker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

import kotlinx.android.synthetic.main.list_item.view.*

/*onClickDelete part is for passing position to MainActivity*/
class ListAdapter(private var lists: MutableList<ListData>, private val listId:String) : RecyclerView.Adapter<ListAdapter.ListViewHolder>(){

    private var listOfThings : MutableList<ListData> = lists

    private lateinit var database: DatabaseReference

    inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item, parent, false)
        return ListViewHolder(view)

    }



    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {


        holder.itemView.apply {
            listOfThings.sortBy { it.position }

            ime_prikaz.setText( lists[position].ime)
            checkBox.isChecked = lists[position].isChecked

            database = Firebase.database.getReference(listId).child("Items")



            btnDeleteEntery.setOnClickListener{
                val i = listOfThings[position].position
                val enteryName = database.child(listOfThings[position].ime)
                enteryName.removeValue()

                removeItem(position)
                ListAdapter(listOfThings,listId)
                

                /*********** reduces the position value of all items located after the item being deleted ***********/
                if(listOfThings.size >= 1) {
                    listOfThings.forEach {
                        if (it.position >= i) {
                            it.position = it.position - 1
                            database.child(it.ime).child("position").setValue(it.position+1)
                        }
                    }
                }

                }


            checkBox.setOnClickListener(){
                if(checkBox.isChecked) {
                    val checkBoxState = true
                    listOfThings[position].isChecked = true
                    database.child(listOfThings[position].ime).child("checked").setValue(checkBoxState)

                    //setBackgroundColor(R.drawable.recyclerview_ticked_border)
                }
                if(!checkBox.isChecked) {
                    val checkBoxState = false
                    listOfThings[position].isChecked = false
                    database.child(listOfThings[position].ime).child("checked").setValue(checkBoxState)

                    //setBackgroundResource(R.drawable.list_of_things_recyclerview_border)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return lists.size
    }

    private fun removeItem(position: Int) {
        listOfThings.removeAt(position)
        notifyDataSetChanged()

    }


}