package com.over3.listmaker

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColor
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.common.util.Hex
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_main.*
import java.util.Collections


class MainActivity : AppCompatActivity() {


    //....................DATABASE..........................//
    private lateinit var database: DatabaseReference



    //....................RECYCLERVIEW......................//
    //listOfThings is a list variable iin MainActivity that stores data about list items
    //List data is a data file needed for RecyclerView
    private var listOfThings : MutableList<ListData> = mutableListOf(
    )





    //list adapter required for recyclerView
    //the part in curly braces is for passing the position and function that is executed on click
    //private val adapter = ListAdapter(listOfThings)





    /******************************** OPTIONS MENU IN APP BAR *********************************/
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_activity_menu,menu)
        return true

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.itemShowListID -> {

                val listId = intent.getStringExtra("EXTRA_LISTID")!!
                showListIDDialog(listId)
                return true
            }
            R.id.itemRate -> {
                showRateDialogue()
                return true
            }

            R.id.itemTutorial -> {
                Intent(this,TutorialActivity::class.java).also {
                    this.startActivity(it)
                }
                return true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }



    /*************************************** ON CREATE ***********************************/

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        //Getting the data passed from StartingActivity
        val listId = intent.getStringExtra("EXTRA_LISTID")!!
        val listName = intent.getStringExtra("EXTRA_LISTNAME")
        val adapter = ListAdapter(listOfThings,listId)

        if(listName != null) {
            supportActionBar?.title = listName
        }



        /***************** CHECK CONECTION *************************/
        val connectivityManager = baseContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.activeNetwork)
        if (networkCapabilities != null /*&& networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)*/) {
            //Toast.makeText(this, "conected", Toast.LENGTH_SHORT).show()
            getListData(listId)
        } else {
            //Toast.makeText(this, "not conected", Toast.LENGTH_SHORT).show()
            listOfThings = PrefConfigListOfThings.readListInPref(listId,baseContext)
        }



        listOfThings.sortBy { it.position }


        // Set List Color

        window.decorView.setBackgroundColor(getColor(R.color.colorPrimary20pct))
        val border =  ContextCompat.getDrawable(this,R.drawable.recyclerview_border) as GradientDrawable




        //...................FIREBASE...............................//
        database = Firebase.database.getReference(listId).child("Items")

        list.adapter = adapter
        list.layoutManager = LinearLayoutManager(this)



        /************ EVENT LISTENER *************************/
            Firebase.database.getReference(listId).child("Items").addChildEventListener(object : ChildEventListener {


            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                //Toast.makeText(baseContext, "Child added", Toast.LENGTH_SHORT).show()
                updateListData(listId)
                PrefConfigListOfThings.writeListInPref(listOfThings,listId,baseContext)
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                updateListData(listId)
                //Toast.makeText(baseContext, "Child changed", Toast.LENGTH_SHORT).show()
                PrefConfigListOfThings.writeListInPref(listOfThings,listId,baseContext)
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
                updateListData(listId)
                //Toast.makeText(baseContext, "Child removerd", Toast.LENGTH_SHORT).show()
                PrefConfigListOfThings.writeListInPref(listOfThings,listId,baseContext)
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                updateListData(listId)
                //Toast.makeText(baseContext, "Child moved", Toast.LENGTH_SHORT).show()
                PrefConfigListOfThings.writeListInPref(listOfThings,listId,baseContext)
            }

            override fun onCancelled(error: DatabaseError) {
                //Toast.makeText(baseContext, "Error updating data", Toast.LENGTH_SHORT).show()
            }

        })



        button.setOnClickListener{
            val imeStr : String=ime.text.toString()

            //..............RECYCLERVIEW.....................//
            // val listData is a value for holding the state of the ListData data class
            if(imeStr == "") {
                Toast.makeText(this, "Please enter the item name", Toast.LENGTH_SHORT).show()
            }
            else {
                if(listOfThings.size <= 100) {
                    val listData = ListData(imeStr, false, listOfThings.size - 1)
                    listOfThings.add(listData)
                    //save list to FIREBASE
                    saveDataToDatabase(imeStr, listId, listOfThings.size - 1)


                    adapter.notifyItemInserted(listOfThings.size - 1)
                    list.adapter = ListAdapter(listOfThings, listId)
                    database.orderByChild("position")
                }
                else {
                    Toast.makeText(this, "You can have a maximum of 100 items in a list", Toast.LENGTH_SHORT).show()
                }
            }
            ime.setText("")
        }

        /***************************** drag and drop ****************************************/
        val touchHelper = ItemTouchHelper(object :ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN,0){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val startPos = viewHolder.absoluteAdapterPosition
                val endPos = target.absoluteAdapterPosition
                val temp = listOfThings[startPos].position
                listOfThings[startPos].position=listOfThings[endPos].position
                listOfThings[endPos].position=temp
                Collections.swap(listOfThings,startPos,endPos)
                list.adapter = ListAdapter(listOfThings,listId)
                saveListItemPositionsToDatabase(listId,listOfThings)
                adapter.notifyItemMoved(startPos,endPos)


                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            }
        })

        touchHelper.attachToRecyclerView(list)


    }

    /**************************** SAVE TO DATABASE *******************************/
    private fun saveDataToDatabase(imeStr: String, listId: String, position: Int){
        database = Firebase.database.getReference(listId).child("Items")
        database.child(imeStr).setValue(ListData(imeStr,false,position))
    }

    /**************** GET LIST DATA FROM DATABASE **********************/

    private fun getListData(listId: String){
        database = FirebaseDatabase.getInstance().getReference(listId).child("Items")

        database.addValueEventListener(object : ValueEventListener {

            override fun onDataChange(snapshot: DataSnapshot) {

                if (snapshot.exists()) {

                    if (listOfThings.isEmpty()) {

                        for (listSnapshot in snapshot.children) {
                            val ime = listSnapshot.child("ime").value.toString()
                            val isChecked = listSnapshot.child("checked").value.toString().toBoolean()
                            val position = listSnapshot.child("position").value.toString().toInt()
                            val data = ListData(ime, isChecked, position)
                            listOfThings.add(data)

                        }

                        list.adapter = ListAdapter(listOfThings,listId)
                    }
                }

            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Failed", Toast.LENGTH_SHORT).show()
            }
        })

    }



    private fun updateListData(listId: String){
        database = FirebaseDatabase.getInstance().getReference(listId).child("Items")

        database.addValueEventListener(object : ValueEventListener {

            override fun onDataChange(snapshot: DataSnapshot) {

                listOfThings.clear()

                    for (listSnapshot in snapshot.children) {
                        val ime = listSnapshot.child("ime").value.toString()
                        val isChecked = listSnapshot.child("checked").value.toString().toBoolean()
                        val position = listSnapshot.child("position").value.toString().toInt()
                        val data = ListData(ime, isChecked, position)
                        listOfThings.add(data)
                    }

                    list.adapter = ListAdapter(listOfThings,listId)
                }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainActivity, "Failed", Toast.LENGTH_SHORT).show()
            }
        })

        PrefConfigListOfThings.writeListInPref(listOfThings,listId,baseContext)

    }

    /*
    private fun getListColor(listId: String){
        val dbRef = Firebase.database.getReference(listId).child("ListColor")
        dbRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                val listColor = dataSnapshot.child("ListColor").value.toString().toInt()
                // Do something with the value
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
            }
        })

        //val color = FirebaseDatabase.getInstance().getReference(listId).child("ListColor").get()
    }
*/

    /**************************** SHOW LIST ID DIALOG ************************/

    private fun showListIDDialog(listId: String) {

        //setting up dialog
        val inflater = layoutInflater
        val dialogLayout = inflater.inflate(R.layout.popup_show_list_id_layout, null)
        val dialog = Dialog(this)
        dialog.setContentView(dialogLayout)

        //showing dialog
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()

        //importing dialog elements
        //importing dialog elements
        val buttonBack = dialogLayout.findViewById<Button>(R.id.buttonBackShowListID)
        val textViewListID = dialogLayout.findViewById<TextView>(R.id.textViewShowListID)

        textViewListID.text = listId

        buttonBack.setOnClickListener{
            dialog.dismiss()
        }
    }

    private fun showRateDialogue() {

        val inflater = layoutInflater
        val dialogLayout = inflater.inflate(R.layout.popup_show_rate, null)
        val dialog = Dialog(this)
        dialog.setContentView(dialogLayout)

        //showing dialog
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    fun saveListItemPositionsToDatabase(listId: String,listOfThings:MutableList<ListData>){
        database = Firebase.database.getReference(listId).child("Items")
        listOfThings.forEach { database.child(it.ime).child("position").setValue(it.position)}
        listOfThings.forEach { database.child(it.ime).child("checked").setValue(it.isChecked)}
    }



}