package com.over3.listmaker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_tutorial.*

class TutorialActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tutorial)


        val tutorial = mutableListOf<TutorialData>(
            (TutorialData(R.drawable.tutorial1,"Press the button in the bottom left corner to create a list.")),
            (TutorialData(R.drawable.tutorial2,"Enter the name of your list.")),
            (TutorialData(R.drawable.tutorial3,"Press \"CONFIRM\".")),
            (TutorialData(R.drawable.tutorial4,"Open the list by pressing on it.")),
            (TutorialData(R.drawable.tutorial5,"Enter the item you want to add.")),
            (TutorialData(R.drawable.tutorial6,"Press add.")),
            (TutorialData(R.drawable.tutorial7,"Let's add some more items!")),
            (TutorialData(R.drawable.tutorial8, "Change the order of the items by pressing and dragging them.")),
            (TutorialData(R.drawable.tutorial9,"To see the ID of this list press \"SHOW LIST ID\".")),
            (TutorialData(R.drawable.tutorial10,"You can copy the ID and send it to another user so they can add your list to their device.")),
            (TutorialData(R.drawable.tutorial11,"Now let's add this list on another device.")),
            (TutorialData(R.drawable.tutorial1,"Press \"ADD LIST BY ID\" to add another users list.")),
            (TutorialData(R.drawable.tutorial12,"Enter the List ID.")),
            (TutorialData(R.drawable.tutorial13,"Click \"Confirm\".")),
            (TutorialData(R.drawable.tutorial14,"The list is now added and can be edited")),

        )

        var i = 0;

        imageView.setImageResource(tutorial[i].image)
        textView.text = tutorial[i].text

        btnNext.setOnClickListener{
            if(i<14) {
                i++
                imageView.setImageResource(tutorial[i].image)
                textView.text = tutorial[i].text
            }
        }

        btnPrevious.setOnClickListener{
            if(i>0) {
                i--
                imageView.setImageResource(tutorial[i].image)
                textView.text = tutorial[i].text
            }
        }
    }
}