package com.over3.listmaker

data class ListData(
    val ime: String,
    var isChecked: Boolean,
    var position: Int
    )
