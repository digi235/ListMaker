package com.over3.listmaker

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


object PrefConfigListOfThings {

    fun writeListInPref(list: MutableList<ListData>, listID: String, context: Context) {
        val sharedPref = context.getSharedPreferences("list_data_prefs", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()

        val gson = Gson()
        val json = gson.toJson(list)
        editor.putString(listID, json)
        editor.apply()
    }

    fun readListInPref(listID: String, context: Context): MutableList<ListData> {
        val sharedPref = context.getSharedPreferences("list_data_prefs", Context.MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPref.getString(listID, "")
        val type = object : TypeToken<MutableList<ListData>>() {}.type
        return gson.fromJson<MutableList<ListData>>(json, type)
    }

}