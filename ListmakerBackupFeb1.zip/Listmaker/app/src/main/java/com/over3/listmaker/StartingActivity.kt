package com.over3.listmaker

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.activity_starting.*
import java.util.*


class StartingActivity : AppCompatActivity() {



    private lateinit var database: DatabaseReference

    private var listOfLists : MutableList<ListOfListsData> = mutableListOf()

    private val defaultListColor : Int = 240116

    private val adapter = ListOfListsAdapter(listOfLists)





    /************************* OPTIONS MENU IN APP BAR *************************/
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.starting_activity_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.itemAddListByID -> {

                showAddListByIDDialog()
                return true

            }

            R.id.itemContact -> {

                showRateDialog()
                return true

            }

            R.id.itemTutorial -> {
                Intent(this,TutorialActivity::class.java).also {
                    this.startActivity(it)
                }
                return true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        listOfLists.add(ListOfListsData("Filler","Filler",0))
        PrefConfig.writeListInPref(baseContext,listOfLists)
        listOfLists.remove(ListOfListsData("Filler","Filler",0))
    }


    /******************** ON CREATE **************************/
    override fun onCreate(savedInstanceState: Bundle?) {

        // Firebase persistence means that the data that changges while the user is offline is cached and stored on firebase and implemented when the user connects again
        FirebaseDatabase.getInstance().setPersistenceEnabled(true)

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_starting)

        listOfLists = mutableListOf()




        /** Shared preferences for determining if it is the first time the app is ran and getting ListOfLists from PrefConfig ******/
        val sharedPreference =  getSharedPreferences("FirstCreatePref", MODE_PRIVATE)
        var editor = sharedPreference.edit()
        editor.apply()

        /****** onFirstCreate *****/
        if (sharedPreference.getBoolean("FirstCreate",true)) {
            PrefConfig.writeListInPref(baseContext, listOfLists)
            listOfLists = PrefConfig.readListFromPref(baseContext)
            editor.putBoolean("FirstCreate",false)
            editor.apply()
        }
        /****** onAnyOtherCreate *****/
        else {
            listOfLists = PrefConfig.readListFromPref(baseContext)

            PrefConfig.writeListInPref(baseContext, listOfLists.distinct() as MutableList<ListOfListsData>)
        }


        listOfLists.remove(ListOfListsData("Filler","Filler",0))


        listOfListRecyclerView.adapter = adapter
        listOfListRecyclerView.layoutManager = LinearLayoutManager(this)

        Log.d("Pref", listOfLists.toString())


        listOfListRecyclerView.adapter = ListOfListsAdapter(listOfLists)


        adapter.notifyDataSetChanged()


        showEnterListNameDialogue()

        val touchHelper = ItemTouchHelper(object :
            ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN,0){
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val startPos = viewHolder.absoluteAdapterPosition
                val endPos = target.absoluteAdapterPosition
                Collections.swap(listOfLists,startPos,endPos)
            listOfListRecyclerView.adapter = ListOfListsAdapter(listOfLists)
            adapter.notifyItemMoved(startPos,endPos)
                PrefConfig.writeListInPref(baseContext,listOfLists)

                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
            }
        })
        touchHelper.attachToRecyclerView(listOfListRecyclerView)



    }

    /************************ SHOW DIALOG FOR ENTERING LIST NAME AND CREATING LIST ********************/
    private fun showEnterListNameDialogue() {
        fab.setOnClickListener {

            //setting up dialog
            val inflater = layoutInflater
            val dialogLayout = inflater.inflate(R.layout.popup_create_list_layout, null)
            val dialog = Dialog(this)
            dialog.setContentView(dialogLayout)

            //showing dialog
            dialog.setCancelable(true)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.show()

            val buttonConfirmListName = dialogLayout.findViewById<Button>(R.id.buttonConfirmListName)
            val editTextListName = dialogLayout.findViewById<EditText>(R.id.editTextListName)

            buttonConfirmListName.setOnClickListener{
                if(listOfLists.size <= 50) {
                    val ListID32 = UUID.randomUUID().toString()
                    val listID = ListID32.take(18)
                    val listName = editTextListName.text.toString()

                    if (listName == "") {
                        Toast.makeText(this, "Please enter the lists name", Toast.LENGTH_SHORT)
                            .show()
                    } else {
                        dialog.dismiss()
                        listOfLists.add(ListOfListsData(listID, listName,defaultListColor))
                        adapter.notifyItemInserted(listOfLists.size - 1)
                        //Setting recyclerView
                        listOfListRecyclerView.adapter = ListOfListsAdapter(listOfLists)
                        //Sending data to database
                        Firebase.database.getReference(listID).child("ListName").setValue(listName)
                        Firebase.database.getReference(listID).child("Items")
                        Firebase.database.getReference(listID).child("ListColor").setValue(R.color.color_default)
                        //Storing data locally
                        //Filler is added to PrefConfig because if it is empty wjen starting the app it will crash
                        listOfLists.add(ListOfListsData("Filler", "Filler",0))
                        PrefConfig.writeListInPref(baseContext, listOfLists)
                        listOfLists.remove(ListOfListsData("Filler", "Filler",0))
                    }
                }
                else{
                    Toast.makeText(this, "You can have a maximum of", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /************************** SHOW DIALOG FOR ADDING LIST BY LIST ID ***************************/
    private fun showAddListByIDDialog() {


        //setting up dialog
        val inflater = layoutInflater
        val dialogLayout = inflater.inflate(R.layout.popup_add_list_by_id_layout, null)
        val dialog = Dialog(this)
        dialog.setContentView(dialogLayout)

        //showing dialog
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()

        //importing dialog elements
        val buttonConfirmListID = dialogLayout.findViewById<Button>(R.id.buttonConfirmListID)
        val editTextListID = dialogLayout.findViewById<EditText>(R.id.editTextListID)

        buttonConfirmListID.setOnClickListener{

            database = FirebaseDatabase.getInstance().reference

            database.addValueEventListener(object : ValueEventListener {

                //Pulling data from database
                override fun onDataChange(snapshot: DataSnapshot) {

                    if (snapshot.exists()) {

                        var listId = editTextListID.text.toString()

                        if (listId == ""){
                            Toast.makeText(baseContext, "Please enter a valid list ID", Toast.LENGTH_SHORT).show()
                        }

                        else {

                            if (snapshot.child(listId).exists()) {

                                val listName =
                                    snapshot.child(listId).child("ListName").value.toString()

                                listOfLists.add(ListOfListsData(listId, listName,defaultListColor))


                                listOfListRecyclerView.adapter = ListOfListsAdapter(listOfLists)

                                listOfLists = listOfLists.distinct() as MutableList<ListOfListsData>

                                PrefConfig.writeListInPref(baseContext, listOfLists)

                                listId = ""
                            }
                        }
                    }
                    else{
                        Toast.makeText(applicationContext, "A list with that ID does not exist", Toast.LENGTH_SHORT).show()
                    }

                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(applicationContext, "Failed", Toast.LENGTH_SHORT).show()
                }
            })
            dialog.dismiss()
        }
    }

    private fun showRateDialog() {

        val inflater = layoutInflater
        val dialogLayout = inflater.inflate(R.layout.popup_show_rate, null)
        val dialog = Dialog(this)
        dialog.setContentView(dialogLayout)

        //showing dialog
        dialog.setCancelable(true)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }




}
