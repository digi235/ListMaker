package com.over3.listmaker

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast

import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.android.synthetic.main.list_of_lists_item.view.*
import kotlin.coroutines.coroutineContext

class ListOfListsAdapter(private var lists: MutableList<ListOfListsData>) : RecyclerView.Adapter<ListOfListsAdapter.ListViewHolder>() {

    private var listOfLists : MutableList<ListOfListsData> = lists

    inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    private lateinit var database: DatabaseReference




    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {


        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_of_lists_item, parent, false)
        return ListViewHolder(view)
    }


    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.itemView.apply {
            listOfListsTextView.text = lists[position].listName

            listOfListsTextView.setOnClickListener{
                Intent(context,MainActivity::class.java).also {
                    it.putExtra("EXTRA_LISTID",listOfLists[position].listID)
                    it.putExtra("EXTRA_LISTNAME",listOfLists[position].listName)
                    context.startActivity(it)
                }
            }



            button_delete_list.setOnClickListener{

                removeItem(position)
                ListOfListsAdapter(listOfLists)

                listOfLists.add(ListOfListsData("Filler","Filler",0))
                PrefConfig.writeListInPref(context,listOfLists)
                listOfLists.remove(ListOfListsData("Filler","Filler",0))

            }
        }
    }


    override fun getItemCount(): Int {
        return lists.size
    }


    private fun removeItem(position: Int) {
        listOfLists.removeAt(position)
        notifyDataSetChanged()

    }
}

