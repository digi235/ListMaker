package com.over3.listmaker

import android.graphics.drawable.Drawable

data class TutorialData (
    val image:Int,
    val text:String
)