package com.over3.listmaker

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


object PrefConfig {
    private const val LIST_KEY = "list_key100"
    fun writeListInPref(context: Context, list:MutableList<ListOfListsData> ){
        val gson = Gson()
        val jsonString = gson.toJson(list)
        val pref = androidx.preference.PreferenceManager.getDefaultSharedPreferences(context)
        val editor = pref.edit()
        editor.putString(LIST_KEY, jsonString)
        editor.apply()
    }

    fun readListFromPref(context: Context): MutableList<ListOfListsData> {
        val pref = androidx.preference.PreferenceManager.getDefaultSharedPreferences(context)
        val jsonString = pref.getString(LIST_KEY,"")
        val gson = Gson()
        val type = object : TypeToken<MutableList<ListOfListsData?>?>() {}.type
        return gson.fromJson(jsonString, type)

    }
}